/*
SCRIPT BY © VYNAA VALERIE 
•• recode kasih credits 
•• contacts: (t.me/VLShop2)
•• instagram: @vynaa_valerie 
•• (github.com/VynaaValerie) 
*/
import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
/*=========== LINK ============*/
global.link = {
	ig: 'https://instagram.com/nusantaraschoolofmagic',
	gh: 'https://github.com/NSMagic',
	gc: 'https://chat.whatsapp.com/DBIH9ozGSfBBMgwbIuBO4f',
	web: 'https://whatsapp.com/channel/0029Vabb59eJP213YtO8Tm1F',
	yt: 'https://youtube.com/@nusantaraschoolofmagic',
	fb: 'https://m.facebook.com',
    tree: 'https://www.vynaachan-api.shop',
	nh: 'https://nhentai.net/g/365296/'	
}
/*===========PAYMENT==========*/
/*============DONASI===========*/
global.pay = {
	dana: '085756507257',
	ovo: '085756507257',
	gopay: '085756507257',
	pulsa: '085756507257',
	qris: 'https://telegra.ph/file/a3653879d96186bdd0467.jpg'
}
/*==============================*/
/*========= NOMOR ============*/
global.info = {
	nomorbot: '6281525808235',
	nomorown: '6285756507257',
	namebot: '𝐍𝐮𝐬𝐚𝐧𝐭𝐚𝐫𝐚-𝐌𝐃',
	nameown: 'ᴳᴱᴿᴬᴸᴰ ᴬᴰᴴᴵᴿᴬᴶᴬˢᴬ ᴶᴼᴴᴬᴺ'
}
/*==============================*/
/*=========== STAFF ============*/
global.owner = [
    ['6285756507257', 'ᴳᴱᴿᴬᴸᴰ ᴬᴰᴴᴵᴿᴬᴶᴬˢᴬ ᴶ', true]
]
global.mods = [] 
global.prems = [] 
/*==============================*/
/*=========== GlobalAPI ============*/
global.zein = 'zenzkey_848b800b1f'
global.skizo = 'pinott'
global.rose = 'Rk-Ashbornt'
global.lol = 'GataDios'
global.lolkey = 'ichanZx'
global.lolkeysapi = [ 'ichanZx' ]
global.neoxr = 'Sanzxdid'
global.can = 'ItsukaChan'
global.btc = 'Rizalzllk'
/*==============================*/
/*==============API ==============*/
global.APIs = {
    // API Prefix
    // name: 'https://website'
    xteam: 'https://api.xteam.xyz',
    lol: 'https://api.lolhuman.xyz',
    males: 'https://malesin.xyz',
    zein: 'https://api.zahwazein.xyz',
    rose: 'https://api.itsrose.life',
    skizo: 'https://skizo.tech',
    saipul: 'https://saipulanuar.cf'
}
global.APIKeys = {
    // APIKey Here
    // 'https://website': 'apikey'
    'https://api.zahwazein.xyz': 'zenzkey_848b800b1f',
    'https://api.xteam.xyz': 'cristian9407',
    'https://api.lolhuman.xyz': 'Abribotxd',
    'https://api.itsrose.life': 'Rk-Ashbornt',
    'https://skizo.tech' : 'pinott'
}
/*==============================*/
/*======== WATERMARK ========*/
global.versibot = '10.15'
global.wm = '𝐍𝐮𝐬𝐚𝐧𝐭𝐚𝐫𝐚-𝐌𝐃' 
global.author = 'ᴳᴱᴿᴬᴸᴰ ᴬᴰᴴᴵᴿᴬᴶᴬˢᴬ ᴶ'
global.wait = '`「 I N  P R O C E S S 」`\n\n*Please wait a few minutes...*'
global.nerror = '`「 E R R O R 」`\n\nSomething went wrong! Please try again and contact owner to fixed!'
/*==============================*/
global.fsizedoc = '99999999999999'
global.fpagedoc = '999'
global.maxwarn = 5;
/*======= TYPE DOCUMENT ======*/
global.doc = {
    pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    pdf: 'application/pdf',
    rtf: 'text/rtf'
}
/*==============================*/
/*========== HIASAN ===========*/
global.decor = {
	menut: '❏═┅═━–〈',
	menub: '┊•',
	menub2: '┊',
	menuf: '┗––––––––––✦',
	hiasan: '꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷',

	menut: '––––––『',
    menuh: '』––––––',
    menub: '┊☃︎ ',
    menuf: '┗━═┅═━––––––๑\n',
	menua: '',
	menus: '☃︎',

	htki: '––––––『',
	htka: '』––––––',
	haki: '┅━━━═┅═❏',
	haka: '❏═┅═━━━┅',
	lopr: 'Ⓟ',
	lolm: 'Ⓛ',
	htjava: '❃'
}
/*=========== FOTO ============*/
global.elainajpg = [
    'https://telegra.ph/file/3e43fcfaea6dc1ba95617.jpg',
    'https://telegra.ph/file/c738a9fc0722a59825cbb.mp4',
    'https://telegra.ph/file/4018167852aef19651f46.jpg',]
global.vynaajpg = 'https://telegra.ph/file/4fca0c3f1f28b06a739e3.jpg',    
global.house = {
    agniferrarius: 'https://telegra.ph/file/ab7467cc6d660715d3c9e.jpg',
    jalasanguinis: 'https://telegra.ph/file/7c421422be5f9ca92fa50.jpg',
    vayuluminis: 'https://telegra.ph/file/c83f477149ca84bc7c82f.jpg',
    prithviviridis: 'https://telegra.ph/file/148d30563ef612036f285.jpg',
    }
global.asramaaf = '120363283633478778'
global.asramajs = '120363266176800545'
global.asramavl = '120363283862304392'
global.asramapv = '120363266240417736'
global.thumbnail = 'https://telegra.ph/file/4fca0c3f1f28b06a739e3.jpg',
/*==============================*/
/*==============================*/
// WELCOME GOOD BYE 
global.wel = 'https://telegra.ph/file/af8f0cbec1d255c311ddf.mp4',
global.good = 'https://telegra.ph/file/b262558cf65343c584e64.mp4',
/*==============================*/
/*==============================*/
global.flaaa = [
    'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=',
    'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&fillColor1Color=%23f2aa4c&fillColor2Color=%23f2aa4c&fillColor3Color=%23f2aa4c&fillColor4Color=%23f2aa4c&fillColor5Color=%23f2aa4c&fillColor6Color=%23f2aa4c&fillColor7Color=%23f2aa4c&fillColor8Color=%23f2aa4c&fillColor9Color=%23f2aa4c&fillColor10Color=%23f2aa4c&fillOutlineColor=%23f2aa4c&fillOutline2Color=%23f2aa4c&backgroundColor=%23101820&text='
]
global.hwaifu = [
    'https://i.pinimg.com/originals/ed/34/f8/ed34f88af161e6278993e1598c29a621.jpg',
    'https://i.pinimg.com/originals/85/4d/bb/854dbbd30304cd69f305352f0183fad0.jpg',
]

/*==================================*/
/*======== STICKER WM ============*/
global.stickpack = 'ЛЦらΛЛŤΛ尺Λ らㄈнØØŁ ØF ௱ΛƓɪㄈ'
global.stickauth = '𝐍𝐮𝐬𝐚𝐧𝐭𝐚𝐫𝐚-𝐌𝐃'

global.multiplier = 38 // The higher, The harder levelup
/*===================================*/
/*============== EMOJI ==============*/
global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            petfood: '🍖',
            iron: '⛓️',
            gold: '🪙',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            skata: '🧩'
        }
        let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
        if (!results.length) return ''
        else return emot[results[0][0]]
    }
}

//------ JANGAN DIUBAH -----
let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
    unwatchFile(file)
    console.log(chalk.redBright("Update 'config.js'"))
    import(`${file}?update=${Date.now()}`)
})
