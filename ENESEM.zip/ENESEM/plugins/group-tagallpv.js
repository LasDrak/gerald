let handler = async(m, { conn, usedPrefix, text, participants }) => {
    let teks = `${text ? text: '*––––––『 Tag All Prithvi Viridis 』––––––*'}`
    for (let mem of participants) {
        teks += `\n@${mem.id.split('@')[0]}`
    }
    
await conn.sendMessage(m.chat, { text: teks,
contextInfo:
					{
						"externalAdReply": {
							"title": "— TAG ALL PRITHVI VIRIDIS🔥",
							"body": "",
							"showAdAttribution": true,
							"mediaType": 1,
							"sourceUrl": '',
							"thumbnailUrl": house.prithviviridis,
							"renderLargerThumbnail": true

						}
					}, mentions: participants.map(a => a.id) })
}
handler.help = ['tagallpv <message> <[hanya bisa digunakan di asrama PV!>']
handler.tags = ['group', 'admin']
handler.command = /^(tagallpvl|allpv)$/i

handler.group = true
handler.admin = true

export default handler

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)