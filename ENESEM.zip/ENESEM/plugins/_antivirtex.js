// tambahin sendiri
export async function before(m, { conn, isAdmin, isBotAdmin }) {
    if (m.isBaileys && m.fromMe) return 
    let user = global.db.data.chats[m.chat]
    if (user.blacklist = true && m.isGroup) {
        if (isBotAdmin && !isAdmin) {
            await conn.sendMessage(m.chat, '[!] Kamu telah masuk ke dalam daftar blacklist.\n\nSecara otomatis kamu akan dikeluarkan oleh bot!', false)
            this.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
        } else {
            await conn.sendMessage(m.chat, 'Tidak dapat mengeluarkan.')
        }
    }
    return
}