let handler = async(m, { conn, usedPrefix, text, participants }) => {
    let teks = `${text ? text: '*––––––『 Tag All Agni Ferarius 』––––––*'}`
    for (let mem of participants) {
        teks += `\n@${mem.id.split('@')[0]}`
    }
    
await conn.sendMessage(m.chat, { text: teks,
contextInfo:
					{
						"externalAdReply": {
							"title": "— TAG ALL AGNI FERRARIUS🔥",
							"body": "",
							"showAdAttribution": true,
							"mediaType": 1,
							"sourceUrl": '',
							"thumbnailUrl": house.agniferrarius,
							"renderLargerThumbnail": true

						}
					}, mentions: participants.map(a => a.id) })
}
handler.help = ['tagallAF <message> <[hanya bisa digunakan di asrama AF!>']
handler.tags = ['group', 'admin']
handler.command = /^(tagallaf|allaf)$/i

handler.group = true
handler.admin = true

export default handler

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)