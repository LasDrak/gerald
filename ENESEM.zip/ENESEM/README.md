<p align="center">
    <img src="https://telegra.ph/file/db089ea429f4e3077a3db.jpg" width="100%" style="margin-left: auto;margin-right: auto;display: block;">
</p>
<h1 align="center">VynaaMD</h1>


## Baca Sebelum Pakai!!
- Ubah Semua Informasi Owner Di Config.js
- Jika Kamu Mengalami Masalah, Bisa Buat Issues Di Page Ini
- Pastikan Isi Apikey Kamu Di Config.js Agar Fiturnya Aktif
- Jika Tidak Fitur Error Ganti Ke Apiknya 
- Untuk Node_Module Kalian Bisa install sendiri 

## Run the bot
```cmd
> npm install 
> npm start
```
### Sedikit Tentang Bot
- ✔️ | **Simple** 
- ✔️ | **No Button** 
- ✔️ | **Multi Device** 
---------
### Fitur Yang Dimiliki
- ✔️ | AI feature 
- ✔️ | Anime 
- ✔️ | Tools 
- ✔️ | Remini
- ✔️ | Quotes
- ✔️ | Confess
- ✔️ | Chat Gpt
- ✔️ | To Anime
- ✔️ | Werewolf Games
- ✔️ | And Others
---------


##
[![Group Chat](https://img.shields.io/badge/Owner%20BOT-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://whatsapp.com/channel/0029VaHPYh6LNSa81M9Xcq1K) 
[![Bot](https://img.shields.io/badge/Bot%20Whatsapp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/6282389924037)


## Thanks To
```bash
𝐀𝐮𝐭𝐡𝐨𝐫 : Vynaa Valerie
Whatsapp : 6282389924037
Thanks To : 
- WhiskeySocket
- Bochilgaming
- IamYanXiao
- Zeltoria
- ShirokamiRyzn
- Xct007
- Ekuzika
- Chaikal
- Dimas Anjay Mabar
- Dan Semua Yang  Berkontribusi Dalam Pengambangan Script Ini 

